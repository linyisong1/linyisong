/**
 * Created by Administrator on 2017/9/19.
 */
(function () {
  'use strict'
  angular.module('starter.controllers')
    .controller('HomeCtrl',['$scope', function ($scope) {
      
      
    }
      ])
})();
